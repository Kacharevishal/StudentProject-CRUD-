package com.student;

import java.io.IOException;
import java.sql.SQLException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



public class EditStudent extends HttpServlet{
protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
		
		int id=Integer.parseInt(req.getParameter("id"));
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String course=req.getParameter("course");
		
		Student s=new Student();
		s.setId(id);
		s.setName(name);
		s.setEmail(email);
		s.setCourse(course);
		
		try {
			Database.updateStudent(s);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		res.sendRedirect("ViewStudent.jsp");
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    int id = Integer.parseInt(req.getParameter("id"));
	    
	    Student s = new Student();
		try {
			s = Database.getStudentById(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    req.setAttribute("student", s);

	    RequestDispatcher rd = req.getRequestDispatcher("ViewStudent.jsp");
	    rd.forward(req, res);
	}

}
