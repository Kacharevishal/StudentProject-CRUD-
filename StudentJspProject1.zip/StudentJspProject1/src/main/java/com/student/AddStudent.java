package com.student;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



public class AddStudent extends HttpServlet{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
	{ 
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String course = request.getParameter("course");
		
		Student s = new Student();
		s.setName(name);
		s.setEmail(email);
		s.setCourse(course);
		
		
			try {
				Database.addStudent(s);
			} catch (SQLException e) {
				e.printStackTrace();
			}
	
		response.sendRedirect("ViewStudent.jsp");
	}

}
