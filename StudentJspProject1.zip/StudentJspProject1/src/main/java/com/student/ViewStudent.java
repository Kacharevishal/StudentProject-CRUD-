package com.student;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class ViewStudent extends HttpServlet {
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws IOException {
	        try {
	            List<Student> list = Database.getAllStudent();
	            response.sendRedirect("ViewStudents.jsp");
	           
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	    }

}
