package com.student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Database {

	public static Connection getConnection() {
		Connection con = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "Vishal2748@");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;

	}

	// Add Student
	public static Student addStudent(Student s) throws SQLException {
		try (Connection con = getConnection()) {
			PreparedStatement pstmt = con.prepareStatement("INSERT INTO studentinfo(name, email, course)VALUES(?,?,?)");
			pstmt.setString(1, s.getName());
			pstmt.setString(2, s.getEmail());
			pstmt.setString(3, s.getCourse());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;

	}

	// Show All Students

	public static List<Student> getAllStudent() throws SQLException {
		List<Student> list = new ArrayList<>();

		try (Connection con = getConnection();

				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM studentinfo")) {

			while (rs.next())

			{
				Student s = new Student();
				s.setId(rs.getInt("id"));
				s.setName(rs.getString("name"));
				s.setEmail(rs.getString("email"));
				s.setCourse(rs.getString("course"));

				list.add(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// Edit Student By id 

	public static Student getStudentById(int id) throws SQLException {
		Student s = new Student();
		try (Connection con = getConnection();
				PreparedStatement pstmt = con.prepareStatement("SELECT * FROM studentinfo WHERE id =?")) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				s.setId(rs.getInt("id"));
				s.setName(rs.getString("name"));
				s.setEmail(rs.getString("email"));
				s.setCourse(rs.getString("course"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}

	// Update Student

	public static void updateStudent(Student s) throws SQLException {
		try (Connection con = getConnection();
				PreparedStatement pstmt = con
						.prepareStatement("UPDATE studentinfo SET name = ?, email = ?, course = ? WHERE ID = ?");) {

			pstmt.setString(1, s.getName());
			pstmt.setString(2, s.getEmail());
			pstmt.setString(3, s.getCourse());
			pstmt.setInt(4, s.getId());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Delete Student

	public static void deleteStudent(int id) throws SQLException {
		try (Connection con = getConnection();
				PreparedStatement pstmt = con.prepareStatement("DELETE FROM studentinfo WHERE ID = ?");) {
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
