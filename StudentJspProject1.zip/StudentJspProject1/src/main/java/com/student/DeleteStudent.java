package com.student;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class DeleteStudent extends HttpServlet{
protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException {
		
		int id=Integer.parseInt(req.getParameter("id"));
		
		try {
			Database.deleteStudent(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		res.sendRedirect("ViewStudent.jsp");
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    doGet(req, res);
	}

}
